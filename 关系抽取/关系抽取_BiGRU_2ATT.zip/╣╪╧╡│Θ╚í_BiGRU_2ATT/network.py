import tensorflow as tf
import numpy as np


class Settings(object):
    def __init__(self):
        self.vocab_size = 16691
        self.num_steps = 70
        self.num_epochs = 10
        self.num_classes = 12
        self.gru_size = 230
        self.keep_prob = 0.5
        self.num_layers = 1
        self.pos_size = 5
        self.pos_num = 123
        # the number of entity pairs(实体对) of each batch during training or testing
        self.big_num = 50 # is batch 


class GRU:
    def __init__(self, is_training, word_embeddings, settings):

        self.num_steps = num_steps = settings.num_steps
        self.vocab_size = vocab_size = settings.vocab_size
        self.num_classes = num_classes = settings.num_classes
        self.gru_size = gru_size = settings.gru_size
        self.big_num = big_num = settings.big_num

        self.input_word = tf.placeholder(dtype=tf.int32, shape=[None, num_steps], name='input_word')
        self.input_pos1 = tf.placeholder(dtype=tf.int32, shape=[None, num_steps], name='input_pos1')
        self.input_pos2 = tf.placeholder(dtype=tf.int32, shape=[None, num_steps], name='input_pos2')
        self.input_y = tf.placeholder(dtype=tf.float32, shape=[None, num_classes], name='input_y')
        self.total_shape = tf.placeholder(dtype=tf.int32, shape=[big_num + 1], name='total_shape')
        total_num = self.total_shape[-1]
        print('total_num')
        print(tf.shape(total_num))
        word_embedding = tf.get_variable(initializer=word_embeddings, name='word_embedding')
        pos1_embedding = tf.get_variable('pos1_embedding', [settings.pos_num, settings.pos_size])
        pos2_embedding = tf.get_variable('pos2_embedding', [settings.pos_num, settings.pos_size])
        print('aaaa')
        print(word_embedding)
        attention_w = tf.get_variable('attention_omega', [gru_size, 1])
        sen_a = tf.get_variable('attention_A', [gru_size])
        sen_r = tf.get_variable('query_r', [gru_size, 1])
        relation_embedding = tf.get_variable('relation_embedding', [self.num_classes, gru_size])
        sen_d = tf.get_variable('bias_d', [self.num_classes])

        gru_cell_forward = tf.contrib.rnn.GRUCell(gru_size)
        gru_cell_backward = tf.contrib.rnn.GRUCell(gru_size)

        if is_training and settings.keep_prob < 1:
            gru_cell_forward = tf.contrib.rnn.DropoutWrapper(gru_cell_forward, output_keep_prob=settings.keep_prob)
            gru_cell_backward = tf.contrib.rnn.DropoutWrapper(gru_cell_backward, output_keep_prob=settings.keep_prob)

        cell_forward = tf.contrib.rnn.MultiRNNCell([gru_cell_forward] * settings.num_layers)
        cell_backward = tf.contrib.rnn.MultiRNNCell([gru_cell_backward] * settings.num_layers)

        sen_repre = []
        sen_alpha = []
        sen_s = []
        sen_out = []
        self.prob = []
        self.predictions = []
        self.loss = []
        self.accuracy = []
        self.total_loss = 0.0

        self._initial_state_forward = cell_forward.zero_state(total_num, tf.float32)
        self._initial_state_backward = cell_backward.zero_state(total_num, tf.float32)

        # embedding layer
        #input_word=[None, num_steps/70]70 is length of a sentence句子长度
        #input_pos1=[None, num_steps/70]
        #input_pos2=[None, num_steps/70]
        #if we=[16898,100],pos1_we=[123,5]123 is the lengtest sentence and  5 is dim ,so inputs_word=[NOn]
        inputs_forward = tf.concat(axis=2, values=[tf.nn.embedding_lookup(word_embedding, self.input_word),
                                                   tf.nn.embedding_lookup(pos1_embedding, self.input_pos1),
                                                   tf.nn.embedding_lookup(pos2_embedding, self.input_pos2)])
        print('bbbb')
        print(inputs_forward)
        inputs_backward = tf.concat(axis=2,
                                    values=[tf.nn.embedding_lookup(word_embedding, tf.reverse(self.input_word, [1])),
                                            tf.nn.embedding_lookup(pos1_embedding, tf.reverse(self.input_pos1, [1])),
                                            tf.nn.embedding_lookup(pos2_embedding,
                                                                   tf.reverse(self.input_pos2, [1]))])

        outputs_forward = []

        state_forward = self._initial_state_forward

        # Bi-GRU layer
        with tf.variable_scope('GRU_FORWARD') as scope:
            for step in range(num_steps):
                if step > 0:
                    scope.reuse_variables()
                (cell_output_forward, state_forward) = cell_forward(inputs_forward[:, step, :], state_forward)
                outputs_forward.append(cell_output_forward)
        print('ccccccccccccccc')
        print(len(outputs_forward))
        print(outputs_forward[0])#230
        outputs_backward = []

        state_backward = self._initial_state_backward
        with tf.variable_scope('GRU_BACKWARD') as scope:
            for step in range(num_steps):
                if step > 0:
                    scope.reuse_variables()
                (cell_output_backward, state_backward) = cell_backward(inputs_backward[:, step, :], state_backward)
                outputs_backward.append(cell_output_backward)
        outputs_forward1 = tf.concat(axis=1, values=outputs_forward)
        print(outputs_forward1)#70*230  230 is the gru length
        output_forward = tf.reshape(outputs_forward1, [total_num, num_steps, gru_size])
        print('out_forward ...........')
        print(output_forward)
        print()
        output_backward = tf.reverse(
            tf.reshape(tf.concat(axis=1, values=outputs_backward), [total_num, num_steps, gru_size]),
            [1])

        # word-level attention layer
        output_h = tf.add(output_forward, output_backward) #forward+backward jin xing information hui zong
        print('output_h is .....')
        print(output_h)
        a0 = tf.reshape(tf.tanh(output_h), [total_num * num_steps, gru_size])  #M=tanh(H)
        #attention_w = tf.get_variable('attention_omega', [gru_size, 1])  
        a1 = tf.matmul(a0, attention_w)# Calculation weight #计算 similary(query,keyi) attention_w is query
        a2 = tf.reshape(a1,[total_num, num_steps])
        a3 = tf.nn.softmax(a2) # 计算权重 α=softmax(wTM)
        a4 = tf.reshape(a3,[total_num, 1, num_steps])
        a5 = tf.matmul(a4,output_h) #加权求和 similary(query,keyi)*values r=HαT
        a6 = tf.reshape(a5,[total_num, gru_size])   
        
        print('a0 is : ........ ')
        print(a0)
        
        print('a1 is : ........ ')
        print(a1)
        
        print('a2 is : ........ ')
        print(a2)
        
        print('a3 is : ........ ')
        print(a3)
        
        print('a4 is : ........ ')
        print(a4)
        
        print('a5 is : ........ ')
        print(a5)
        
        print('a6 is : ........ ')
        print(a6)
        
        #a6 = attention_r
        attention_r = tf.reshape(
                tf.matmul(
                        tf.reshape(
                                tf.nn.softmax(
                    tf.reshape(
                            tf.matmul(tf.reshape(tf.tanh(output_h), [total_num * num_steps, gru_size]), attention_w),
                       [total_num, num_steps])), [total_num, 1, num_steps]), output_h), [total_num, gru_size])
        print('attention is : ..........')
        print([total_num * num_steps, gru_size])
        print(attention_r)
        print(attention_w)
        '''下边用的是多示例学习方法，每个包一个类别，在一个包中，有的句子中的关系不是对的，只是含有两个识别而已。采用attention方法，让神经网络学习到不同句子对这个包的关系提供不同的权重。
           sen_repre[i]就是句子向量，下边代码中，绝大多是sen_repre[i]是一个句子，但是30个里边还有多个句子情况，多个句子情况用attention才有用，其实的都是一个句子，那么attention的权重还是1.'''
        # sentence-level attention layer
        #sen_a = tf.get_variable('attention_A', [gru_size])
        #sen_r = tf.get_variable('query_r', [gru_size, 1]) 句子级别的query
        for i in range(big_num):    #big_num实体对个数

            sen_repre.append(tf.tanh(attention_r[self.total_shape[i]:self.total_shape[i + 1]]))
            batch_size = self.total_shape[i + 1] - self.total_shape[i]# 一个实体对可能对应着不同的句子，batch_size因此可能取值不同
            #print('sen_repre ...............')
            #print(len(sen_repre))
            #print(sen_repre[0])
            #print(batch_size)
            # sen_repre[i] shape is [230]
            #sen_repre[i] is sentence vector
            b0 = tf.multiply(sen_repre[i], sen_a) #sen_repre[i]就是刚才上边的a6了，是一个特定维度的向量，可以表示整个句子。
            print('b0 is .........')
            print(b0)
            
            b1= tf.matmul(b0, sen_r) # #计算相似度
            print('b1 is .........')
            print(b1)
            
            b2 = tf.reshape(b1, [batch_size]) #batch_size表示sen_repre[i]中含有几个句子
            print('b2 is .........')
            print(b2)
            
            b3 = tf.nn.softmax(b2)#softmax操作，如果只有一个句子那么softmax之后还是1，
            #print('b3 is .........')
            #print(b3)
            
            b4 = tf.reshape(b3,[1, batch_size])
            #print('b4 is .........')
            #print(b4)
            
            b5 = sen_alpha.append(b4)
            #print('b5 is .........')
            #print(b5)
            
            #attention_w = tf.get_variable('attention_omega', [gru_size, 1])
            #sen_a = tf.get_variable('attention_A', [gru_size])
            #sen_r = tf.get_variable('query_r', [gru_size, 1])
            #relation_embedding = tf.get_variable('relation_embedding', [self.num_classes, gru_size])
            #sen_d = tf.get_variable('bias_d', [self.num_classes])
            sen_alpha.append(
                tf.reshape(tf.nn.softmax(tf.reshape(tf.matmul(tf.multiply(sen_repre[i], sen_a), sen_r), [batch_size])),
                           [1, batch_size]))
            #tf.matmul(sen_alpha[i], sen_repre[i])  sen_alpha[i]是权重矩阵，sen_repre[i]是句子表示，相乘就是每个句子对这种关系的贡献度了。
            sen_s.append(tf.reshape(tf.matmul(sen_alpha[i], sen_repre[i]), [gru_size, 1]))
            #tf.matmul(relation_embedding, sen_s[i]) relation_embedding是一个n*300,n表示类的个数，相当于接了一个全连接输出。
            sen_out.append(tf.add(tf.reshape(tf.matmul(relation_embedding, sen_s[i]), [self.num_classes]), sen_d))

            self.prob.append(tf.nn.softmax(sen_out[i]))

            with tf.name_scope("output"):
                self.predictions.append(tf.argmax(self.prob[i], 0, name="predictions"))

            with tf.name_scope("loss"):
                self.loss.append(
                    tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=sen_out[i], labels=self.input_y[i])))
                if i == 0:
                    self.total_loss = self.loss[i]
                else:
                    self.total_loss += self.loss[i]

            # tf.summary.scalar('loss',self.total_loss)
            # tf.scalar_summary(['loss'],[self.total_loss])
            with tf.name_scope("accuracy"):
                self.accuracy.append(
                    tf.reduce_mean(tf.cast(tf.equal(self.predictions[i], tf.argmax(self.input_y[i], 0)), "float"),
                                   name="accuracy"))

        # tf.summary.scalar('loss',self.total_loss)
        tf.summary.scalar('loss', self.total_loss)
        # regularization
        self.l2_loss = tf.contrib.layers.apply_regularization(regularizer=tf.contrib.layers.l2_regularizer(0.0001),
                                                              weights_list=tf.trainable_variables())
        self.final_loss = self.total_loss + self.l2_loss
        tf.summary.scalar('l2_loss', self.l2_loss)
        tf.summary.scalar('final_loss', self.final_loss)
